def hello_once(name="placeholder"):
    print('Hello {}'.format(name))

def hello_many(items=["placeholder"]):
    for item in items:
        hello_once(item)